<?php
function hnysweb_rebuild_Main() {
	global $zbp;
    $zbp->RegBuildModule('catalog','hnysweb_catalog');
}
function hnysweb_catalog() {
	global $zbp;
	$s = '';
	if ($zbp->option['ZC_MODULE_CATALOG_STYLE'] == '2') {
		foreach ($zbp->categorysbyorder as $key => $value) {
			if ($value->Level == 0) {
				$s .= '<li id="navbar-category-'.$value->ID.'" ><a href="' . $value->Url . '"><i class="iconfont ' . $value->Metas->hnysweb_icon . '"></i>' . $value->Name . '</a><!--' . $value->ID . 'begin--><!--' . $value->ID . 'end--></li>';
			}
		}
		foreach ($zbp->categorysbyorder as $key => $value) {
			if ($value->Level == 1) {
				$s = str_replace('<!--' . $value->ParentID . 'end-->', '<li id="navbar-category-'.$value->ID.'" class="li-subcate-'.$value->ID.'"><a href="' . $value->Url . '"><i class="iconfont ' . $value->Metas->hnysweb_icon . '"></i>' . $value->Name . '</a><!--' . $value->ID . 'begin--><!--' . $value->ID . 'end--></li><!--' . $value->ParentID . 'end-->', $s);
			}
		}
		foreach ($zbp->categorysbyorder as $key => $value){
			if($value->Level == 2) {
				$s = str_replace('<!--' . $value->ParentID . 'end-->', '<li id="navbar-category-'.$value->ID.'" class="li-subcate-'.$value->ID.'"><a href="' . $value->Url . '"><i class="iconfont ' . $value->Metas->hnysweb_icon . '"></i>' . $value->Name . '</a><!--' . $value->ID . 'begin--><!--' . $value->ID . 'end--></li><!--' . $value->ParentID . 'end-->', $s);
			}
		}foreach($zbp->categorysbyorder as $key => $value){
			if ($value->Level == 3) {
				$s = str_replace('<!--' . $value->ParentID . 'end-->', '<li id="navbar-category-'.$value->ID.'" class="li-subcate-'.$value->ID.'"><a href="' . $value->Url . '"><i class="iconfont ' . $value->Metas->hnysweb_icon . '"></i>' . $value->Name . '</a><!--' . $value->ID . 'begin--><!--' . $value->ID . 'end--></li><!--' . $value->ParentID . 'end-->', $s);
			}
		}foreach($zbp->categorysbyorder as $key => $value){
			$s = str_replace('<!--' . $value->ID . 'begin--><!--' . $value->ID . 'end-->', '', $s);
		}foreach($zbp->categorysbyorder as $key => $value){
			$s = str_replace('<!--' . $value->ID . 'begin-->', '<ul class="sub-menu">', $s);
			$s = str_replace('<!--' . $value->ID . 'end-->', '</ul>', $s);
		}
	}elseif($zbp->option['ZC_MODULE_CATALOG_STYLE'] == '1'){
		foreach ($zbp->categorysbyorder as $key => $value){
			$s .= '<li id="navbar-category-'.$value->ID.'">' . $value->Symbol . '<a href="' . $value->Url . '"><i class="iconfont ' . $value->Metas->hnysweb_icon . '"></i>' . $value->Name . '</a></li>';
		}
	}else{
		foreach ($zbp->categorysbyorder as $key => $value){
			$s .= '<li id="navbar-category-'.$value->ID.'"><a href="' . $value->Url . '"><i class="iconfont ' . $value->Metas->hnysweb_icon . '"></i>' . $value->Name . '</a></li>';
		}
	}
	return $s;
}
//文章高级选项
function hnysweb_article_Thumbnail(){
global $zbp,$article;
	if($article->Type=="0"){
		echo "<script type=\"text/javascript\" src=\"{$zbp->host}zb_users/theme/hnysweb/style/js/lib.upload.js\"></script>";
        echo '<div class="editmod"><label for="meta_Setwailian" class="editinputname">网址图标/二维码</label>
              <div class="uploadimg"><input name="meta_pic" id="edtTitle" type="text" class="uplod_img" style="width:60%;margin-bottom:15px;" value="'.$article->Metas->pic.'" />
              <strong style="color: #ffffff; font-size: 14px;padding: 6px 18px 6px 18px; background: #3a6ea5;border: 1px solid #3399cc; cursor: pointer;">浏览文件</strong>
              </div>
              <label for="meta_Setwailian" class="editinputname">网址跳转链接<span class="star">(带http://,二维码不填！)</span></label>
              <input type="text" name="meta_Setwailian" id="edtTitle" style="width:99%;margin-bottom:15px;" value="'.htmlspecialchars($article->Metas->Setwailian).'">
              <label for="meta_Setjs" class="editinputname">网址或微信简介<span class="star">(*)</span></label>
              <input type="text" name="meta_Setjs" id="edtTitle" style="width:99%;margin-bottom:15px;" value="'.htmlspecialchars($article->Metas->Setjs).'">';
        echo '<label for="meta_Setwailian" class="editinputname" >热门推荐</label>';      						
	    $cnziduan='hots';        	  	
	    $ar=explode('|',$cnziduan);    	  	 	  
	    foreach ($ar as $r) {
		echo '<input type="hidden"  name="meta_'.$r.'" value=""/><label>
		<input type="checkbox"name="meta_'.$r.'" value="'.htmlspecialchars($r).'" ';
		if ($article->Metas->$r == $r){echo 'checked="checked"';}    	     	 
		echo ' class="'.$r.'" /></label>&nbsp;&nbsp;';     		  			
	} 
	echo'选中后显示在首页的热门推荐</div>';

	}
}
function hnysweb_article_seo(){
    global $zbp,$article;
	if($article->Type=="0"){
	echo "<script type=\"text/javascript\" src=\"{$zbp->host}zb_users/theme/hnysweb/admin/css/jquery.min.js\"></script>";
	echo "<script type=\"text/javascript\" src=\"{$zbp->host}zb_users/theme/hnysweb/admin/css/common.js\"></script>";
	echo '<div class="editmod">
       <label class="editinputname">SEO设置</span><span style="margin:0 0 0 15px ;color:#1d4c7d" id="seob" class="title">点击展开</span></label>
       <div id="seoshow" style="display:none;">
	   <input type="text" id="edtTitle" style="width:99%;margin-bottom:5px;" name="meta_hyarticletitle" value="'.htmlspecialchars($article->Metas->hyarticletitle).'" placeholder="SEO标题"/>
       <input type="text" id="edtTitle" style="width:99%;margin-bottom:5px;" name="meta_hyarticlekeywords" value="'.htmlspecialchars($article->Metas->hyarticlekeywords).'" placeholder="SEO关键词，注意：1、关键词之间用英文逗号分开；2、这里的关键词不能替代文章标签；3、设置了文章标签可以不用设置这里的关键词。"/>
       <input type="text" id="edtTitle" style="width:99%;margin-bottom:15px;" name="meta_hyarticledescription" value="'.htmlspecialchars($article->Metas->hyarticledescription).'" placeholder="SEO描述"/>
	   </div>
       </div>';
}
}
//分类高级选项
function hnysweb_cate_AO(){
    global $zbp,$cate;
	
	echo '<div id="alias" class="editmod">
       <span class="title" style="margin-right:5px;">分类小图标</span>
       <input type="text" style="width:300px;" name="meta_hnysweb_icon" value="'.htmlspecialchars($cate->Metas->hnysweb_icon).'"/>
	   <p><span style=" color:#FF0000;">在分类名称前显示！这里使用的是填写图标标签调用的方法。</span>&nbsp;<a target="_blank" href="/zb_users/theme/hnysweb/style/css/demo_fontclass.html">→点击访问图标库，选择图标。</a></p>
       <p><span class="title" style="margin:0 5px 0 0;">二维码分类</span><input name="meta_hnysweb_erweima" type="text" value="'.$cate->Metas->hnysweb_erweima.'" class="checkbox" style="display:none;" />
	   <span class="title" style="margin:0 5px 0 15px;">文章分类</span><input name="meta_hnysweb_lista" type="text" value="'.$cate->Metas->hnysweb_lista.'" class="checkbox" style="display:none;" />&nbsp;&nbsp;默认的分类模板是网址分类,如果需要发布文章选择文章分类。</p>  
       <p><span class="title" style="margin-right:15px;">分类的列表页显示文章的数量</span><input type="text" style="width:200px;" name="meta_hnysweb_page" id="keyword" value="'.htmlspecialchars($cate->Metas->hnysweb_page).'" placeholder="不设置则按照系统默认"/></p>
	   </div>
	    ';
}
function hnysweb_cate_seo(){
    global $zbp,$cate;
	echo "<script type=\"text/javascript\" src=\"{$zbp->host}zb_users/theme/hnysweb/admin/css/jquery.min.js\"></script>";
	echo "<script type=\"text/javascript\" src=\"{$zbp->host}zb_users/theme/hnysweb/admin/css/common.js\"></script>";
	echo '<div id="alias" class="editmod">
       <p><span style="margin:0 15px 0 0;" class="title">SEO设置</span><span style="margin:0 0 0 15px ;color:#1d4c7d" id="seob" class="title">点击展开</span><font color="#FF0000">（* 该功能为主题自带，不填写则按主题默认显示）</font></p>
       <div id="seoshow" style="display:none;"><p><input type="text" style="width:200px;margin:0 30px 0 0;" name="meta_hycatetitle" value="'.htmlspecialchars($cate->Metas->hycatetitle).'" placeholder="SEO标题"/>
       <input type="text" style="width:300px;margin:0 30px 0 0;" name="meta_hycatekeywords" value="'.htmlspecialchars($cate->Metas->hycatekeywords).'" placeholder="SEO关键词"/>
       <input type="text" style="width:500px;" name="meta_hycatedescription" value="'.htmlspecialchars($cate->Metas->hycatedescription).'" placeholder="SEO描述"/>
	   </p></div>
       </div>';
}
function hnysweb_tag_seo(){
    global $zbp,$tag;
	echo "<script type=\"text/javascript\" src=\"{$zbp->host}zb_users/theme/hnysweb/admin/css/jquery.min.js\"></script>";
	echo "<script type=\"text/javascript\" src=\"{$zbp->host}zb_users/theme/hnysweb/admin/css/common.js\"></script>";
	echo '<div id="alias" class="editmod">
       <p><span style="margin:0 15px 0 0;" class="title">SEO设置</span><span style="margin:0 15px 0 0;color:#1d4c7d" id="seob" class="title">点击展开</span><font color="#FF0000">（* 该功能为主题自带，不填写则按主题默认显示）</font></p>
       <div id="seoshow" style="display:none;"><p><input type="text" style="width:200px;margin:0 30px 0 0;" name="meta_hytagtitle" value="'.htmlspecialchars($tag->Metas->hytagtitle).'" placeholder="SEO标题"/>
       <input type="text" style="width:300px;margin:0 30px 0 0;" name="meta_hytagkeywords" value="'.htmlspecialchars($tag->Metas->hytagkeywords).'" placeholder="SEO关键词"/>
       <input type="text" style="width:500px;" name="meta_hytagdescription" value="'.htmlspecialchars($tag->Metas->hytagdescription).'" placeholder="SEO描述"/></p></div>
	   <p><span style="margin:0 15px 0 0;" class="title">标签的列表页显示文章的数量</span>
       <input type="text" style="width:200px;" name="meta_hnysweb_page" id="keyword" value="'.htmlspecialchars($tag->Metas->hnysweb_page).'" placeholder="不设置则按照系统默认"/>
     </p> </div>';
}
function hnysweb_Filter_Plugin_ViewList_Core(&$type, &$page, &$category, &$author, &$datetime, &$tag, &$w,&$pagebar){
global $zbp;
if($type=="category"){
	if($category->Metas->hnysweb_page && $category->Metas->hnysweb_page!=''){
	 $pagebar->PageCount = $category->Metas->hnysweb_page;
	}else{
    $pagebar->PageCount = $zbp->displaycount;
	}
}elseif($type=="tag"){
	if($tag->Metas->hnysweb_page && $tag->Metas->hnysweb_page!=''){
	$pagebar->PageCount = $tag->Metas->hnysweb_page;
	}else{
	$pagebar->PageCount = $zbp->displaycount;
	}
}elseif($type=="author"){
	if($author->Metas->hnysweb_page &&  $author->Metas->hnysweb_page!=''){
	$pagebar->PageCount = $author->Metas->hnysweb_page;
	}else{
	$pagebar->PageCount = $zbp->displaycount;
	}
}
}
function hnysweb_Filter_Plugin_Member_Edit_Response(){
global $member;
echo '<div id="alias" class="editmod"><span style="margin:0 15px 0 0;" class="title">作者的列表页显示文章的数量</span>
<input type="text" style="width:200px;" name="meta_hnysweb_page" id="keyword" value="'.htmlspecialchars($member->Metas->hnysweb_page).'" placeholder="不设置则按照系统默认"/>';
}

?>